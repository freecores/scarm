
 bool g_interrupt=0;
  int  g_count=0;