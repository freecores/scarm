// scBX.h: interface for the scBX class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCBX_H__FC5E6448_AB29_11D6_BB1E_000000000000__INCLUDED_)
#define AFX_SCBX_H__FC5E6448_AB29_11D6_BB1E_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "scARMInstruction.h"
class scBX : public scARMInstruction  
{
public:
	scBX();
	virtual ~scBX();

};

#endif // !defined(AFX_SCBX_H__FC5E6448_AB29_11D6_BB1E_000000000000__INCLUDED_)
